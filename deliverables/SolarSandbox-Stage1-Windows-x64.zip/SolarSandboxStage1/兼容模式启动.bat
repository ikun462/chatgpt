@echo off
chcp 65001 >nul
cd /d "%~dp0"
"%~dp0SolarSandbox.exe" --rendering-method gl_compatibility %*
if errorlevel 1 pause
