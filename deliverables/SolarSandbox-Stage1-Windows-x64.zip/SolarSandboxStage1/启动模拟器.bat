@echo off
chcp 65001 >nul
cd /d "%~dp0"
"%~dp0SolarSandbox.exe" --rendering-method forward_plus --rendering-driver vulkan %*
if errorlevel 1 pause
